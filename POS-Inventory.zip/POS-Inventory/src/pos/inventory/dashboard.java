/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pos.inventory;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.Toolkit;
import net.proteanit.sql.DbUtils;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import javax.swing.JOptionPane;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import pos.inventory.database.dbconfig;
public class dashboard extends javax.swing.JFrame {
public static Connection conn = null;
public static PreparedStatement pst= null;
public static ResultSet rs =null;
    private void seticon() {
        //To change body of generated methods, choose Tools | Templates.
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("icon.png")));
    }
    public static void logs()
    {
        try
        {
            String sql = "Select Fullname,DateTime,Remarks from tbl_logs";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            jTable5.setModel(DbUtils.resultSetToTableModel(rs));
            jTable5.getTableHeader().setFont(new Font(null,Font.PLAIN,16));
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null,e.fillInStackTrace(),"ERROR",JOptionPane.ERROR_MESSAGE);
        }
        
    }
    
    public static void chart()
    {
        Calendar cal = Calendar.getInstance();
        String month = new SimpleDateFormat("MM").format(cal.getTime());
        String year = new SimpleDateFormat("yyyy").format(cal.getTime());
        try
        {
            conn = dbconfig.db();
            String sql = "Select SUM(totalAmount)Amount,TransactionDate as date from tblsales "
                    + "WHERE date_format(TransactionDate,'%m')='"+month+"' "
                    + "AND date_format(TransactionDate,'%Y')='"+year+"' GROUP BY TransactionDate";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            DefaultCategoryDataset dataset = new DefaultCategoryDataset();
            while(rs.next())
            {
                String date = rs.getString("date");
                Double amt = rs.getDouble("Amount");
                dataset.setValue(amt,date,date);
                JFreeChart chart = ChartFactory.createBarChart("Daily Sales Income", "Date", "Amount", dataset, PlotOrientation.VERTICAL, false,true,false);
                ChartPanel panel = new ChartPanel(chart);
                daily_sales_chart.setLayout(new java.awt.BorderLayout());
                daily_sales_chart.add(panel,BorderLayout.CENTER);
                daily_sales_chart.validate();
            }
            //monthly
            String sqls = "Select SUM(Qty)total,itemDescription as product from tblitems "
                    + "WHERE date_format(TransactionDate,'%m')='"+month+"' "
                    + "AND date_format(TransactionDate,'%Y')='"+year+"' GROUP BY productID ORDER BY total DESC LIMIT 10";
            pst = conn.prepareStatement(sqls);
            rs = pst.executeQuery();
            DefaultPieDataset datasets = new DefaultPieDataset();
            while(rs.next())
            {
                String product = rs.getString("product");
                Double qty = rs.getDouble("total");
                datasets.setValue(product,qty);
                JFreeChart charts = ChartFactory.createPieChart("In Demand Products", datasets, true,true,false);
                ChartPanel panel = new ChartPanel(charts);               
                monthly_chart.setLayout(new java.awt.BorderLayout());
                monthly_chart.add(panel,BorderLayout.CENTER);
                monthly_chart.validate();
            }
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null,e.fillInStackTrace(),"ERROR",JOptionPane.ERROR_MESSAGE);
        }
    }
    //other reports
    public static void others()
    {
        try
        {
           conn = dbconfig.db();
           String sql = "Select FORMAT(SUM(Qty),0)total from tblothers WHERE TypeofReport='Used Item'";
           pst = conn.prepareStatement(sql);
           rs = pst.executeQuery();
           if(rs.next())
           {
               txtUsed.setText(rs.getString("total"));
           }
           //used item
           String sqls = "Select FORMAT(SUM(Qty),0)total from tblothers WHERE TypeofReport='Damaged Item'";
           pst = conn.prepareStatement(sqls);
           rs = pst.executeQuery();
           if(rs.next())
           {
             txtDamaged.setText(rs.getString("total"));
           }
           //Lost item
           String sql2 = "Select FORMAT(SUM(Qty),0)total from tblothers WHERE TypeofReport='Missing Item'";
           pst = conn.prepareStatement(sql2);
           rs = pst.executeQuery();
           if(rs.next())
           {
             txtLost.setText(rs.getString("total"));
           }
           //count on hand items
           String sql1 = "Select FORMAT(SUM(Qty),0)total from tblinventory";
           pst = conn.prepareStatement(sql1);
           rs = pst.executeQuery();
           if(rs.next())
           {
             txtOnhand.setText(rs.getString("total"));
           }
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null,e.getMessage(),"ERROR",JOptionPane.ERROR_MESSAGE);
        }
    }
    public static void dash()
    {
        Calendar cal = Calendar.getInstance();
        String month = new SimpleDateFormat("MM").format(cal.getTime());
        String day = new SimpleDateFormat("dd").format(cal.getTime());
        String year = new SimpleDateFormat("yyyy").format(cal.getTime());
        try
        {
            conn = dbconfig.db();
            String sql = "Select FORMAT(IFNULL(COUNT(salesID),0),0)total from tblsales "
                    + "where date_format(TransactionDate,'%m')='"+month+"' AND date_format(TransactionDate,'%Y')='"+year+"'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next())
            {
                total_trxn.setText(rs.getString("total"));
            }
            //monthly sales
            String sqls = "Select FORMAT(IFNULL(SUM(totalAmount),0),2)total from tblsales where "
                    + "date_format(TransactionDate,'%m')='"+month+"' AND date_format(TransactionDate,'%Y')='"+year+"'";
            pst = conn.prepareStatement(sqls);
            rs = pst.executeQuery();
            if(rs.next())
            {
                current_month.setText(rs.getString("total"));
            }
            //monthly sales
            String sqls2 = "Select FORMAT(IFNULL(SUM(totalAmount),0),2)total from tblsales where "
                    + "date_format(TransactionDate,'%Y')='"+year+"'";
            pst = conn.prepareStatement(sqls2);
            rs = pst.executeQuery();
            if(rs.next())
            {
                label_yearly.setText(rs.getString("total"));
            }
            //previous sales
            String sql2 = "Select FORMAT(IFNULL(SUM(totalAmount),0),2)total from tblsales where "
                    + "date_format(TransactionDate,'%m')='"+month+"'-1 AND date_format(TransactionDate,'%Y')='"+year+"'";
            pst = conn.prepareStatement(sql2);
            rs = pst.executeQuery();
            if(rs.next())
            {
                previous_sales.setText(rs.getString("total"));
            }
            //daily sales
            String query = "Select FORMAT(IFNULL(SUM(totalAmount),0),2)total from tblsales where "
                    + "date_format(TransactionDate,'%m')='"+month+"' AND date_format(TransactionDate,'%d')='"+day+"' AND "
                    + "date_format(TransactionDate,'%Y')='"+year+"'";
            pst = conn.prepareStatement(query);
            rs = pst.executeQuery();
            if(rs.next())
            {
                daily_sales.setText(rs.getString("total"));
            }
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null,e.getMessage(),"ERROR",JOptionPane.ERROR_MESSAGE);
        }
    }

//create method without parameters
public static void stocks()
{
    try
    {
        conn = dbconfig.db();
        String sql = "Select COUNT(productID)total from tblinventory WHERE Qty<=0";
        pst = conn.prepareStatement(sql);
        rs = pst.executeQuery();
        if(rs.next())
        {
            label_outstocks.setText(rs.getString("total"));
        }
        String sqls = "Select COUNT(productID)total from tblinventory WHERE Qty>5";
        pst = conn.prepareStatement(sqls);
        rs = pst.executeQuery();
        if(rs.next())
        {
            label_instocks.setText(rs.getString("total"));
        }
        
        String sqls1 = "Select COUNT(productID)total from tblinventory WHERE Qty BETWEEN 1 AND 5";
        pst = conn.prepareStatement(sqls1);
        rs = pst.executeQuery();
        if(rs.next())
        {
            label_criticalstock.setText(rs.getString("total"));
        }
        
        String query = "Select FORMAT(IFNULL(SUM(Qty),0),0)total from tblinventory";
        pst = conn.prepareStatement(query);
        rs = pst.executeQuery();
        if(rs.next())
        {
            currentstocks.setText(rs.getString("total"));
        }
        
        String querys = "Select FORMAT(IFNULL(SUM(costPrice),0),2)total from tblinventory";
        pst = conn.prepareStatement(querys);
        rs = pst.executeQuery();
        if(rs.next())
        {
            stocksvalue.setText(rs.getString("total"));
        }
    }
    catch(SQLException e)
    {
        JOptionPane.showMessageDialog(null,e.getMessage(),"ERROR",JOptionPane.ERROR_MESSAGE);
    }
}
public static void loaduser()
{
   try
   {
       conn = dbconfig.db();
       String sql = "Select Username,Password,Fullname,Role from tblaccount WHERE Role<>'Superuser'";
       pst = conn.prepareStatement(sql);
       rs = pst.executeQuery();
       tbluser.setModel(DbUtils.resultSetToTableModel(rs));
   }
   catch(SQLException e)
   {
       JOptionPane.showMessageDialog(null,e.getMessage(),"ERROR",JOptionPane.ERROR_MESSAGE);
   }
}
//load supplier
public static void loadsupplier()
{
   try
   {
       conn = dbconfig.db();
       String sql = "Select BrandName as Brand,supplierName as Supplier,Address,contactNumber as Contact,emailAdd as Email,"
               + "IF(Status=0,'Inactive','Active')Status from tblsupplier";
       pst = conn.prepareStatement(sql);
       rs = pst.executeQuery();
       tblsupplier.setModel(DbUtils.resultSetToTableModel(rs));
       tblsupplier.getTableHeader().setFont(new Font(null,Font.PLAIN,16));
       
       String query = "Select a.BrandName as Brand,b.CategoryName as Category from tblsupplier a INNER JOIN tblcategory b ON a.supID=b.supID GROUP BY b.catID";
       pst = conn.prepareStatement(query);
       rs = pst.executeQuery();
       tblcategory.setModel(DbUtils.resultSetToTableModel(rs));
   }
   catch(SQLException e)
   {
       JOptionPane.showMessageDialog(null,e.getMessage(),"ERROR",JOptionPane.ERROR_MESSAGE);
   }
}

public static void products()
{
   try
   {
       conn = dbconfig.db();
       String sql = "Select a.productCode as Code,a.itemDescription as Description,b.BrandName as Brand,b.supplierName as Supplier,c.CategoryName as Category"
               + " from tblproduct a LEFT JOIN tblsupplier b ON b.supID=a.supID LEFT JOIN tblcategory c ON c.catID=a.catID GROUP BY a.productCode";
       pst = conn.prepareStatement(sql);
       rs = pst.executeQuery();
       tblproduct.setModel(DbUtils.resultSetToTableModel(rs));      
   }
   catch(SQLException e)
   {
       JOptionPane.showMessageDialog(null,e.getMessage(),"ERROR",JOptionPane.ERROR_MESSAGE);
   }
}

public static void loaditem()
{
    try
    {
        conn = dbconfig.db();
        String sql = "Select a.productCode as Code,a.itemDescription as Description,c.BrandName as Brand,"
                + "FORMAT(IFNULL(b.costPrice,0),2)Cost,Unit,"
                + "FORMAT(IFNULL(SUM(b.Qty),0),0)Qty,b.itemCode as ItemCode,"
                + "IF(b.Qty<=0,'Out of Stocks',IF(b.Qty<=b.critical_level,'Critical Stocks','In Stocks'))Status from tblproduct a INNER JOIN tblinventory b ON a.productID=b.productID"
                + " LEFT JOIN tblsupplier c ON c.supID=a.supID GROUP BY b.Unit,a.productID";
        pst = conn.prepareStatement(sql);
        rs = pst.executeQuery();
        jTable1.setModel(DbUtils.resultSetToTableModel(rs));
    }
    catch(SQLException e)
    {
        JOptionPane.showMessageDialog(null,e.getMessage(),"ERROR",JOptionPane.ERROR_MESSAGE);
    }
}
    /**
     * Creates new form dashboard
     */
    int runtime = 0;
    public dashboard() {
        initComponents();loaduser();loadsupplier();products();loaditem();
        seticon();stocks();dash();others();chart();logs();
        jTable1.getTableHeader().setFont(new Font(null,Font.PLAIN,16));
        tblproduct.getTableHeader().setFont(new Font(null,Font.PLAIN,16));
        tblcategory.getTableHeader().setFont(new Font(null,Font.PLAIN,16));
        tbluser.getTableHeader().setFont(new Font(null,Font.PLAIN,16));
        jTable2.getTableHeader().setFont(new Font(null,Font.PLAIN,16));
        jTable3.getTableHeader().setFont(new Font(null,Font.PLAIN,16));
        jTable4.getTableHeader().setFont(new Font(null,Font.PLAIN,16));
        tblsales.getTableHeader().setFont(new Font(null,Font.PLAIN,16));
        tbl_others.getTableHeader().setFont(new Font(null,Font.PLAIN,16));
        new Thread()
       {
           public void run()
           {
               while(runtime==0)
               {
                   Calendar cal = new GregorianCalendar();
                   int hour = cal.get(Calendar.HOUR);
                   int minute = cal.get(Calendar.MINUTE);
                   int second = cal.get(Calendar.SECOND);
                   int am_pm = cal.get(Calendar.AM_PM);
                   int month = cal.get(Calendar.MONTH);
                   int year = cal.get(Calendar.YEAR);
                   int day= cal.get(Calendar.DAY_OF_MONTH);
                   
                   String times = "";
                   String d = Integer.toString(month+1);
                   if(am_pm == 1)
                   {
                       times = "PM";
                   }else
                   {
                       times = "AM";
                   }
                   time.setText(year + "-" + d + "-" + day + " "+ hour + ":" + minute + ":" + second + " " + times);
      
                   
               }
           }
       }.start();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        panel_1 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        total_trxn = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        previous_sales = new javax.swing.JLabel();
        daily_sales_chart = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        current_month = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        daily_sales = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        label_yearly = new javax.swing.JLabel();
        monthly_chart = new javax.swing.JPanel();
        panel_2 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        label_outstocks = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        currentstocks = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        stocksvalue = new javax.swing.JLabel();
        searchitem = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        btnStocks = new javax.swing.JButton();
        jPanel12 = new javax.swing.JPanel();
        label_instocks = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel26 = new javax.swing.JPanel();
        label_criticalstock = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        panel_4 = new javax.swing.JPanel();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel8 = new javax.swing.JPanel();
        fromdate = new com.toedter.calendar.JDateChooser();
        todate = new com.toedter.calendar.JDateChooser();
        btnExport = new javax.swing.JButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        btnLoad = new javax.swing.JButton();
        jPanel25 = new javax.swing.JPanel();
        to_sales_date = new com.toedter.calendar.JDateChooser();
        from_sales_date = new com.toedter.calendar.JDateChooser();
        btnGenerate = new javax.swing.JButton();
        jScrollPane7 = new javax.swing.JScrollPane();
        tblsales = new javax.swing.JTable();
        total_Sales = new javax.swing.JLabel();
        total_Sales1 = new javax.swing.JLabel();
        btnexport_sales = new javax.swing.JButton();
        total_Sales3 = new javax.swing.JLabel();
        total_vat = new javax.swing.JLabel();
        jPanel28 = new javax.swing.JPanel();
        jScrollPane8 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        toProductDate = new com.toedter.calendar.JDateChooser();
        fromProductDate = new com.toedter.calendar.JDateChooser();
        searchbtn = new javax.swing.JButton();
        exportbtn = new javax.swing.JButton();
        jPanel30 = new javax.swing.JPanel();
        jScrollPane10 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();
        category_tdate = new com.toedter.calendar.JDateChooser();
        category_fdate = new com.toedter.calendar.JDateChooser();
        export_category = new javax.swing.JButton();
        search_category = new javax.swing.JButton();
        total_Sales2 = new javax.swing.JLabel();
        total_category = new javax.swing.JLabel();
        jPanel20 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_others = new javax.swing.JTable();
        jPanel17 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        txtOnhand = new javax.swing.JLabel();
        jPanel18 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        txtUsed = new javax.swing.JLabel();
        jPanel19 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        txtDamaged = new javax.swing.JLabel();
        jPanel16 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        txtLost = new javax.swing.JLabel();
        others_tdate = new com.toedter.calendar.JDateChooser();
        others_fdate = new com.toedter.calendar.JDateChooser();
        select_category = new javax.swing.JComboBox<>();
        search_others_btn = new javax.swing.JButton();
        export_others_btn = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        panel_3 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbluser = new javax.swing.JTable();
        searchuser = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        new_username = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        new_password = new javax.swing.JPasswordField();
        jLabel5 = new javax.swing.JLabel();
        new_name = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        new_role = new javax.swing.JComboBox<>();
        btnRegister = new javax.swing.JButton();
        jPanel31 = new javax.swing.JPanel();
        jScrollPane11 = new javax.swing.JScrollPane();
        jTable5 = new javax.swing.JTable();
        searchlogs = new javax.swing.JTextField();
        panel_5 = new javax.swing.JPanel();
        jTabbedPane3 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblsupplier = new javax.swing.JTable();
        search_supplier = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane9 = new javax.swing.JScrollPane();
        tblcategory = new javax.swing.JTable();
        btnCategory = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tblproduct = new javax.swing.JTable();
        searchproduct = new javax.swing.JTextField();
        btnProduct = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jPanel13 = new javax.swing.JPanel();
        menuMaintenance = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jPanel21 = new javax.swing.JPanel();
        menuDashboard = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jPanel22 = new javax.swing.JPanel();
        menuInventory = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jPanel23 = new javax.swing.JPanel();
        menuReport = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        user_name = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        time = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        btnLogout = new javax.swing.JLabel();
        jPanel24 = new javax.swing.JPanel();
        menuPOS = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jPanel27 = new javax.swing.JPanel();
        menuRecords = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jPanel29 = new javax.swing.JPanel();
        jLabel32 = new javax.swing.JLabel();
        menuAccount = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Sales and Inventory System");
        setBackground(new java.awt.Color(153, 0, 153));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(153, 0, 153));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(new java.awt.CardLayout());

        panel_1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel5.setBackground(new java.awt.Color(204, 0, 204));
        jPanel5.setForeground(new java.awt.Color(255, 255, 255));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("Total Transaction");
        jPanel5.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 220, 30));

        total_trxn.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        total_trxn.setForeground(new java.awt.Color(255, 255, 255));
        total_trxn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        total_trxn.setText("0.00");
        jPanel5.add(total_trxn, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 200, 80));

        panel_1.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 10, 240, 130));

        jPanel6.setBackground(new java.awt.Color(204, 0, 204));
        jPanel6.setForeground(new java.awt.Color(255, 255, 255));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("Previous Month Sales");
        jPanel6.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 220, 30));

        previous_sales.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        previous_sales.setForeground(new java.awt.Color(255, 255, 255));
        previous_sales.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        previous_sales.setText("0.00");
        jPanel6.add(previous_sales, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 200, 80));

        panel_1.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 10, 240, 130));

        daily_sales_chart.setBackground(new java.awt.Color(255, 255, 255));
        daily_sales_chart.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        panel_1.add(daily_sales_chart, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, 810, 450));

        jPanel14.setBackground(new java.awt.Color(204, 0, 204));
        jPanel14.setForeground(new java.awt.Color(255, 255, 255));
        jPanel14.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel16.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel16.setText("Current Month Sales");
        jPanel14.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 220, 30));

        current_month.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        current_month.setForeground(new java.awt.Color(255, 255, 255));
        current_month.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        current_month.setText("0.00");
        jPanel14.add(current_month, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 200, 80));

        panel_1.add(jPanel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 10, 240, 130));

        jPanel15.setBackground(new java.awt.Color(204, 0, 204));
        jPanel15.setForeground(new java.awt.Color(255, 255, 255));
        jPanel15.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel18.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel18.setText("Daily Sales Income");
        jPanel15.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 220, 30));

        daily_sales.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        daily_sales.setForeground(new java.awt.Color(255, 255, 255));
        daily_sales.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        daily_sales.setText("0.00");
        jPanel15.add(daily_sales, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 200, 80));

        panel_1.add(jPanel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 10, 250, 130));

        jPanel7.setBackground(new java.awt.Color(204, 0, 204));
        jPanel7.setForeground(new java.awt.Color(255, 255, 255));
        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel12.setText("Yearly Sales Income");
        jPanel7.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 220, 30));

        label_yearly.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        label_yearly.setForeground(new java.awt.Color(255, 255, 255));
        label_yearly.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        label_yearly.setText("0.00");
        jPanel7.add(label_yearly, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 200, 80));

        panel_1.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 240, 130));

        monthly_chart.setBackground(new java.awt.Color(255, 255, 255));
        monthly_chart.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        panel_1.add(monthly_chart, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 150, 430, 450));

        jPanel1.add(panel_1, "card2");

        panel_2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel9.setBackground(new java.awt.Color(204, 0, 204));
        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        label_outstocks.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        label_outstocks.setForeground(new java.awt.Color(255, 255, 255));
        label_outstocks.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        label_outstocks.setText("0");
        label_outstocks.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        label_outstocks.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                label_outstocksMouseClicked(evt);
            }
        });
        jPanel9.add(label_outstocks, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 110, 20));

        jLabel17.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel17.setText("Out of Stocks");
        jPanel9.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 110, 20));

        panel_2.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 10, 130, 60));

        jPanel10.setBackground(new java.awt.Color(204, 0, 204));
        jPanel10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel14.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel14.setText("Current Stocks");
        jPanel10.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 110, 20));

        currentstocks.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        currentstocks.setForeground(new java.awt.Color(255, 255, 255));
        currentstocks.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        currentstocks.setText("0.00");
        jPanel10.add(currentstocks, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 110, 20));

        panel_2.add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 130, 60));

        jPanel11.setBackground(new java.awt.Color(204, 0, 204));
        jPanel11.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel15.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel15.setText("Stocks Value");
        jPanel11.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 110, 20));

        stocksvalue.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        stocksvalue.setForeground(new java.awt.Color(255, 255, 255));
        stocksvalue.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        stocksvalue.setText("0.00");
        jPanel11.add(stocksvalue, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 110, 20));

        panel_2.add(jPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 10, 130, 60));

        searchitem.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        searchitem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchitemActionPerformed(evt);
            }
        });
        searchitem.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                searchitemKeyTyped(evt);
            }
        });
        panel_2.add(searchitem, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 30, 330, 40));

        jLabel13.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel13.setText("Search :");
        panel_2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 10, 130, 20));

        btnStocks.setBackground(new java.awt.Color(204, 0, 204));
        btnStocks.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        btnStocks.setForeground(new java.awt.Color(255, 255, 255));
        btnStocks.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pos/images/plus.png"))); // NOI18N
        btnStocks.setText("New Stocks");
        btnStocks.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStocksActionPerformed(evt);
            }
        });
        panel_2.add(btnStocks, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 30, 160, 40));

        jPanel12.setBackground(new java.awt.Color(204, 0, 204));
        jPanel12.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        label_instocks.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        label_instocks.setForeground(new java.awt.Color(255, 255, 255));
        label_instocks.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        label_instocks.setText("0");
        label_instocks.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        label_instocks.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                label_instocksMouseClicked(evt);
            }
        });
        jPanel12.add(label_instocks, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 110, 20));

        jLabel21.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 255, 255));
        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel21.setText("In Stocks");
        jPanel12.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 110, 20));

        panel_2.add(jPanel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 10, 130, 60));

        jTable1.setAutoCreateRowSorter(true);
        jTable1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jTable1.setFont(new java.awt.Font("Dialog", 0, 16)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane6.setViewportView(jTable1);

        panel_2.add(jScrollPane6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 1270, 520));

        jPanel26.setBackground(new java.awt.Color(204, 0, 204));
        jPanel26.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        label_criticalstock.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        label_criticalstock.setForeground(new java.awt.Color(255, 255, 255));
        label_criticalstock.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        label_criticalstock.setText("0");
        label_criticalstock.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        label_criticalstock.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                label_criticalstockMouseClicked(evt);
            }
        });
        jPanel26.add(label_criticalstock, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 110, 20));

        jLabel30.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(255, 255, 255));
        jLabel30.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel30.setText("Critical Stocks");
        jPanel26.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 110, 20));

        panel_2.add(jPanel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 10, 130, 60));

        jPanel1.add(panel_2, "card3");

        panel_4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTabbedPane2.setBackground(new java.awt.Color(204, 0, 204));
        jTabbedPane2.setForeground(new java.awt.Color(0, 0, 0));
        jTabbedPane2.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N

        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        fromdate.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel8.add(fromdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 250, 40));

        todate.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel8.add(todate, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 10, 250, 40));

        btnExport.setBackground(new java.awt.Color(204, 0, 204));
        btnExport.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        btnExport.setForeground(new java.awt.Color(255, 255, 255));
        btnExport.setText("Export");
        btnExport.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnExport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExportActionPerformed(evt);
            }
        });
        jPanel8.add(btnExport, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 10, 100, 40));

        jTable2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jTable2.setFont(new java.awt.Font("Dialog", 0, 16)); // NOI18N
        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ItemDescription", "ItemCode", "OnHand", "SoldItem", "UsedItem", "DamagedItem", "MissingItem", "TotalItem"
            }
        ));
        jTable2.setEnabled(false);
        jScrollPane5.setViewportView(jTable2);

        jPanel8.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 1260, 510));

        btnLoad.setBackground(new java.awt.Color(204, 0, 204));
        btnLoad.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        btnLoad.setForeground(new java.awt.Color(255, 255, 255));
        btnLoad.setText("Search");
        btnLoad.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnLoad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLoadActionPerformed(evt);
            }
        });
        jPanel8.add(btnLoad, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 10, 100, 40));

        jTabbedPane2.addTab("Inventory Report", jPanel8);

        jPanel25.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        to_sales_date.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel25.add(to_sales_date, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 10, 250, 40));

        from_sales_date.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel25.add(from_sales_date, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 250, 40));

        btnGenerate.setBackground(new java.awt.Color(204, 0, 204));
        btnGenerate.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        btnGenerate.setForeground(new java.awt.Color(255, 255, 255));
        btnGenerate.setText("Generate");
        btnGenerate.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnGenerate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGenerateActionPerformed(evt);
            }
        });
        jPanel25.add(btnGenerate, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 10, 100, 40));

        tblsales.setFont(new java.awt.Font("Dialog", 0, 16)); // NOI18N
        tblsales.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "TransactionDate", "TransactionCode", "Gross_Profit", "Vat", "Net_Profit", "Username"
            }
        ));
        tblsales.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblsalesMouseClicked(evt);
            }
        });
        jScrollPane7.setViewportView(tblsales);

        jPanel25.add(jScrollPane7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 1260, 460));

        total_Sales.setFont(new java.awt.Font("Dialog", 0, 30)); // NOI18N
        total_Sales.setForeground(new java.awt.Color(0, 0, 0));
        total_Sales.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        total_Sales.setText("0.00");
        total_Sales.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel25.add(total_Sales, new org.netbeans.lib.awtextra.AbsoluteConstraints(1060, 530, 210, 40));

        total_Sales1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        total_Sales1.setForeground(new java.awt.Color(0, 0, 0));
        total_Sales1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        total_Sales1.setText("VAT (12%)");
        total_Sales1.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        total_Sales1.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        jPanel25.add(total_Sales1, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 530, 90, 40));

        btnexport_sales.setBackground(new java.awt.Color(204, 0, 204));
        btnexport_sales.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        btnexport_sales.setForeground(new java.awt.Color(255, 255, 255));
        btnexport_sales.setText("Export");
        btnexport_sales.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnexport_sales.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnexport_salesActionPerformed(evt);
            }
        });
        jPanel25.add(btnexport_sales, new org.netbeans.lib.awtextra.AbsoluteConstraints(643, 10, 100, 40));

        total_Sales3.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        total_Sales3.setForeground(new java.awt.Color(0, 0, 0));
        total_Sales3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        total_Sales3.setText("Net Profit");
        total_Sales3.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        total_Sales3.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        jPanel25.add(total_Sales3, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 530, 80, 40));

        total_vat.setFont(new java.awt.Font("Dialog", 0, 30)); // NOI18N
        total_vat.setForeground(new java.awt.Color(0, 0, 0));
        total_vat.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        total_vat.setText("0.00");
        total_vat.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel25.add(total_vat, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 530, 190, 40));

        jTabbedPane2.addTab("Sales Report", jPanel25);

        jPanel28.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable3.setFont(new java.awt.Font("Dialog", 0, 16)); // NOI18N
        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Date", "ItemCode", "Description", "Qty", "Amount"
            }
        ));
        jTable3.setEnabled(false);
        jScrollPane8.setViewportView(jTable3);

        jPanel28.add(jScrollPane8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 1260, 510));

        toProductDate.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel28.add(toProductDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 10, 250, 40));

        fromProductDate.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel28.add(fromProductDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 250, 40));

        searchbtn.setBackground(new java.awt.Color(204, 0, 204));
        searchbtn.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        searchbtn.setForeground(new java.awt.Color(255, 255, 255));
        searchbtn.setText("Search");
        searchbtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        searchbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchbtnActionPerformed(evt);
            }
        });
        jPanel28.add(searchbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 10, 130, 40));

        exportbtn.setBackground(new java.awt.Color(204, 0, 204));
        exportbtn.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        exportbtn.setForeground(new java.awt.Color(255, 255, 255));
        exportbtn.setText("Export");
        exportbtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        exportbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exportbtnActionPerformed(evt);
            }
        });
        jPanel28.add(exportbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 10, 130, 40));

        jTabbedPane2.addTab("Product Sales Report", jPanel28);

        jPanel30.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable4.setFont(new java.awt.Font("Dialog", 0, 16)); // NOI18N
        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Category", "Amount"
            }
        ));
        jTable4.setEnabled(false);
        jScrollPane10.setViewportView(jTable4);

        jPanel30.add(jScrollPane10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 62, 1260, 510));

        category_tdate.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel30.add(category_tdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 10, 250, 40));

        category_fdate.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel30.add(category_fdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 250, 40));

        export_category.setBackground(new java.awt.Color(204, 0, 204));
        export_category.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        export_category.setForeground(new java.awt.Color(255, 255, 255));
        export_category.setText("Export");
        export_category.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        export_category.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                export_categoryActionPerformed(evt);
            }
        });
        jPanel30.add(export_category, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 10, 110, 40));

        search_category.setBackground(new java.awt.Color(204, 0, 204));
        search_category.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        search_category.setForeground(new java.awt.Color(255, 255, 255));
        search_category.setText("Search");
        search_category.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        search_category.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                search_categoryActionPerformed(evt);
            }
        });
        jPanel30.add(search_category, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 10, 110, 40));

        total_Sales2.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        total_Sales2.setForeground(new java.awt.Color(0, 0, 0));
        total_Sales2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        total_Sales2.setText("Total");
        total_Sales2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        total_Sales2.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        jPanel30.add(total_Sales2, new org.netbeans.lib.awtextra.AbsoluteConstraints(960, 10, 90, 40));

        total_category.setFont(new java.awt.Font("Dialog", 0, 30)); // NOI18N
        total_category.setForeground(new java.awt.Color(0, 0, 0));
        total_category.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        total_category.setText("0.00");
        total_category.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel30.add(total_category, new org.netbeans.lib.awtextra.AbsoluteConstraints(1060, 10, 210, 40));

        jTabbedPane2.addTab("Category Sales Report", jPanel30);

        jPanel20.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel20.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tbl_others.setAutoCreateRowSorter(true);
        tbl_others.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        tbl_others.setFont(new java.awt.Font("Dialog", 0, 16)); // NOI18N
        tbl_others.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Date", "ItemCode", "Description", "Qty", "Remarks"
            }
        ));
        tbl_others.setEnabled(false);
        jScrollPane1.setViewportView(tbl_others);

        jPanel20.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 1080, 510));

        jPanel17.setBackground(new java.awt.Color(204, 0, 204));
        jPanel17.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel10.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("On Hand Item(s)");
        jPanel17.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 5, 150, 30));

        txtOnhand.setFont(new java.awt.Font("Dialog", 0, 30)); // NOI18N
        txtOnhand.setForeground(new java.awt.Color(255, 255, 255));
        txtOnhand.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        txtOnhand.setText("0");
        jPanel17.add(txtOnhand, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, 130, 60));

        jPanel20.add(jPanel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 70, 170, 110));

        jPanel18.setBackground(new java.awt.Color(204, 0, 204));
        jPanel18.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel11.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setText("Used Item(s)");
        jPanel18.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 5, 150, 30));

        txtUsed.setFont(new java.awt.Font("Dialog", 0, 30)); // NOI18N
        txtUsed.setForeground(new java.awt.Color(255, 255, 255));
        txtUsed.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        txtUsed.setText("0");
        jPanel18.add(txtUsed, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, 130, 60));

        jPanel20.add(jPanel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 200, 170, 110));

        jPanel19.setBackground(new java.awt.Color(204, 0, 204));
        jPanel19.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel19.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel19.setText("Damage Item(s)");
        jPanel19.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 5, 150, 30));

        txtDamaged.setFont(new java.awt.Font("Dialog", 0, 30)); // NOI18N
        txtDamaged.setForeground(new java.awt.Color(255, 255, 255));
        txtDamaged.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        txtDamaged.setText("0");
        jPanel19.add(txtDamaged, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, 130, 60));

        jPanel20.add(jPanel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 330, 170, 110));

        jPanel16.setBackground(new java.awt.Color(204, 0, 204));
        jPanel16.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel20.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel20.setText("Missing Item(s)");
        jPanel16.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 5, 150, 30));

        txtLost.setFont(new java.awt.Font("Dialog", 0, 30)); // NOI18N
        txtLost.setForeground(new java.awt.Color(255, 255, 255));
        txtLost.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        txtLost.setText("0");
        jPanel16.add(txtLost, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, 130, 60));

        jPanel20.add(jPanel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 460, 170, 110));

        others_tdate.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel20.add(others_tdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 10, 240, 40));

        others_fdate.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel20.add(others_fdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 240, 40));

        select_category.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choose", "Damaged Item", "Missing Item", "Used Item" }));
        select_category.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel20.add(select_category, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 10, 180, 40));

        search_others_btn.setBackground(new java.awt.Color(204, 0, 204));
        search_others_btn.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        search_others_btn.setForeground(new java.awt.Color(255, 255, 255));
        search_others_btn.setText("Search");
        search_others_btn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        search_others_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                search_others_btnActionPerformed(evt);
            }
        });
        jPanel20.add(search_others_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 10, 140, 40));

        export_others_btn.setBackground(new java.awt.Color(204, 0, 204));
        export_others_btn.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        export_others_btn.setForeground(new java.awt.Color(255, 255, 255));
        export_others_btn.setText("Export");
        export_others_btn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        export_others_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                export_others_btnActionPerformed(evt);
            }
        });
        jPanel20.add(export_others_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 10, 140, 40));

        jButton2.setBackground(new java.awt.Color(204, 0, 204));
        jButton2.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Refresh");
        jButton2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel20.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1160, 10, 110, 40));

        jTabbedPane2.addTab("Others", jPanel20);

        panel_4.add(jTabbedPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1290, 620));

        jPanel1.add(panel_4, "card5");

        panel_3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTabbedPane1.setBackground(new java.awt.Color(204, 0, 204));
        jTabbedPane1.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N

        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tbluser.setAutoCreateRowSorter(true);
        tbluser.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        tbluser.setFont(new java.awt.Font("Dialog", 0, 16)); // NOI18N
        tbluser.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tbluser.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbluserMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tbluser);

        jPanel4.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 940, 510));

        searchuser.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        searchuser.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                searchuserKeyTyped(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                searchuserKeyPressed(evt);
            }
        });
        jPanel4.add(searchuser, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 940, 40));

        jLabel2.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel2.setText("Register Account:");
        jPanel4.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 10, 170, 30));

        jLabel3.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel3.setText("Password");
        jPanel4.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 120, 130, 30));

        new_username.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel4.add(new_username, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 80, 300, 40));

        jLabel4.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel4.setText("Username");
        jPanel4.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 50, 130, 30));

        new_password.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel4.add(new_password, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 150, 300, 40));

        jLabel5.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel5.setText("User Role");
        jPanel4.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 260, 130, 30));

        new_name.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel4.add(new_name, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 220, 300, 40));

        jLabel6.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel6.setText("Complete Name");
        jPanel4.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 190, 130, 30));

        new_role.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choose", "Superuser", "End-user" }));
        new_role.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel4.add(new_role, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 290, 300, 40));

        btnRegister.setBackground(new java.awt.Color(204, 0, 204));
        btnRegister.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        btnRegister.setForeground(new java.awt.Color(255, 255, 255));
        btnRegister.setText("Register");
        btnRegister.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnRegister.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegisterActionPerformed(evt);
            }
        });
        jPanel4.add(btnRegister, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 350, 300, 40));

        jTabbedPane1.addTab("Accounts", jPanel4);

        jPanel31.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable5.setFont(new java.awt.Font("Dialog", 0, 16)); // NOI18N
        jTable5.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable5.setEnabled(false);
        jScrollPane11.setViewportView(jTable5);

        jPanel31.add(jScrollPane11, new org.netbeans.lib.awtextra.AbsoluteConstraints(13, 60, 1260, 510));

        searchlogs.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        searchlogs.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                searchlogsKeyPressed(evt);
            }
        });
        jPanel31.add(searchlogs, new org.netbeans.lib.awtextra.AbsoluteConstraints(15, 10, 1260, 40));

        jTabbedPane1.addTab("Activity Logs", jPanel31);

        panel_3.add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1290, 620));

        jPanel1.add(panel_3, "card4");

        panel_5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTabbedPane3.setBackground(new java.awt.Color(204, 0, 204));
        jTabbedPane3.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tblsupplier.setAutoCreateRowSorter(true);
        tblsupplier.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        tblsupplier.setFont(new java.awt.Font("Dialog", 0, 16)); // NOI18N
        tblsupplier.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblsupplier.setEnabled(false);
        jScrollPane3.setViewportView(tblsupplier);

        jPanel2.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 92, 930, 480));

        search_supplier.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        search_supplier.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                search_supplierKeyTyped(evt);
            }
        });
        jPanel2.add(search_supplier, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 930, 30));

        jButton1.setBackground(new java.awt.Color(204, 0, 204));
        jButton1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pos/images/plus.png"))); // NOI18N
        jButton1.setText("Add");
        jButton1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 10, 80, 30));

        jLabel1.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel1.setText("Search");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 120, 30));

        tblcategory.setFont(new java.awt.Font("Dialog", 0, 16)); // NOI18N
        tblcategory.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane9.setViewportView(tblcategory);

        jPanel2.add(jScrollPane9, new org.netbeans.lib.awtextra.AbsoluteConstraints(953, 50, 320, 520));

        btnCategory.setBackground(new java.awt.Color(204, 0, 204));
        btnCategory.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        btnCategory.setForeground(new java.awt.Color(255, 255, 255));
        btnCategory.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pos/images/plus.png"))); // NOI18N
        btnCategory.setText("Category");
        btnCategory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCategoryActionPerformed(evt);
            }
        });
        jPanel2.add(btnCategory, new org.netbeans.lib.awtextra.AbsoluteConstraints(1140, 10, 130, 30));

        jTabbedPane3.addTab("Brand", jPanel2);

        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tblproduct.setAutoCreateRowSorter(true);
        tblproduct.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        tblproduct.setFont(new java.awt.Font("Dialog", 0, 16)); // NOI18N
        tblproduct.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblproduct.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        tblproduct.setEnabled(false);
        jScrollPane4.setViewportView(tblproduct);

        jPanel3.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 82, 1260, 490));

        searchproduct.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        searchproduct.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                searchproductKeyTyped(evt);
            }
        });
        jPanel3.add(searchproduct, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 1140, 30));

        btnProduct.setBackground(new java.awt.Color(204, 0, 204));
        btnProduct.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        btnProduct.setForeground(new java.awt.Color(255, 255, 255));
        btnProduct.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pos/images/plus.png"))); // NOI18N
        btnProduct.setText("Product");
        btnProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProductActionPerformed(evt);
            }
        });
        jPanel3.add(btnProduct, new org.netbeans.lib.awtextra.AbsoluteConstraints(1160, 40, 110, 30));

        jLabel7.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        jLabel7.setText("Search");
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 120, 30));

        jTabbedPane3.addTab("Products", jPanel3);

        panel_5.add(jTabbedPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1290, 610));

        jPanel1.add(panel_5, "card6");

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 60, -1, 620));

        jPanel13.setBackground(new java.awt.Color(255, 255, 255));
        jPanel13.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel13.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        menuMaintenance.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        menuMaintenance.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pos/images/maintenance.png"))); // NOI18N
        menuMaintenance.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuMaintenanceMouseClicked(evt);
            }
        });
        jPanel13.add(menuMaintenance, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 60, 50));

        jLabel28.setFont(new java.awt.Font("Dialog", 0, 9)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(0, 0, 0));
        jLabel28.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel28.setText("Maintenance");
        jPanel13.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(-17, 50, 90, -1));

        getContentPane().add(jPanel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 380, 60, 70));

        jPanel21.setBackground(new java.awt.Color(255, 255, 255));
        jPanel21.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel21.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        menuDashboard.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        menuDashboard.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pos/images/dashboard.png"))); // NOI18N
        menuDashboard.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuDashboardMouseClicked(evt);
            }
        });
        jPanel21.add(menuDashboard, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 60, 50));

        jLabel25.setFont(new java.awt.Font("Dialog", 0, 9)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(0, 0, 0));
        jLabel25.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel25.setText("Dashboard");
        jPanel21.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 60, -1));

        getContentPane().add(jPanel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 60, 70));

        jPanel22.setBackground(new java.awt.Color(255, 255, 255));
        jPanel22.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel22.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        menuInventory.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        menuInventory.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pos/images/inventory.png"))); // NOI18N
        menuInventory.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuInventoryMouseClicked(evt);
            }
        });
        jPanel22.add(menuInventory, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 60, 50));

        jLabel26.setFont(new java.awt.Font("Dialog", 0, 9)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(0, 0, 0));
        jLabel26.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel26.setText("Inventory");
        jPanel22.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(3, 50, 50, -1));

        getContentPane().add(jPanel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, 60, 70));

        jPanel23.setBackground(new java.awt.Color(255, 255, 255));
        jPanel23.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel23.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        menuReport.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        menuReport.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pos/images/business-report.png"))); // NOI18N
        menuReport.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuReportMouseClicked(evt);
            }
        });
        jPanel23.add(menuReport, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 60, 50));

        jLabel27.setFont(new java.awt.Font("Dialog", 0, 9)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(0, 0, 0));
        jLabel27.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel27.setText("Reports");
        jPanel23.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(3, 50, 50, -1));

        getContentPane().add(jPanel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 60, 70));

        jLabel22.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(0, 0, 0));
        jLabel22.setText("Sales and Inventory System");
        getContentPane().add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 450, 30));

        user_name.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        user_name.setForeground(new java.awt.Color(0, 0, 0));
        user_name.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        user_name.setText("Guest");
        user_name.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(user_name, new org.netbeans.lib.awtextra.AbsoluteConstraints(1160, 10, 180, 20));

        jLabel23.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel23.setText("Welcome");
        getContentPane().add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 10, 100, 20));

        time.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        time.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        getContentPane().add(time, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 30, 270, 30));

        jLabel24.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(0, 0, 0));
        jLabel24.setText("M.B. Chavez Poultry Supply");
        getContentPane().add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 450, 30));

        btnLogout.setFont(new java.awt.Font("Dialog", 0, 12)); // NOI18N
        btnLogout.setForeground(new java.awt.Color(204, 0, 153));
        btnLogout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pos/images/logout.png"))); // NOI18N
        btnLogout.setText("Sign Out");
        btnLogout.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        btnLogout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnLogoutMouseClicked(evt);
            }
        });
        getContentPane().add(btnLogout, new org.netbeans.lib.awtextra.AbsoluteConstraints(1160, 30, 120, 30));

        jPanel24.setBackground(new java.awt.Color(255, 255, 255));
        jPanel24.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel24.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        menuPOS.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        menuPOS.setForeground(new java.awt.Color(0, 0, 0));
        menuPOS.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        menuPOS.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pos/images/pos.png"))); // NOI18N
        menuPOS.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuPOSMouseClicked(evt);
            }
        });
        jPanel24.add(menuPOS, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 60, 50));

        jLabel34.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(0, 0, 0));
        jLabel34.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel34.setText("POS");
        jPanel24.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(3, 50, 50, -1));

        getContentPane().add(jPanel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 460, 60, 70));

        jPanel27.setBackground(new java.awt.Color(255, 255, 255));
        jPanel27.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel27.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        menuRecords.setFont(new java.awt.Font("Dialog", 0, 9)); // NOI18N
        menuRecords.setForeground(new java.awt.Color(0, 0, 0));
        menuRecords.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        menuRecords.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pos/images/cloud-database.png"))); // NOI18N
        menuRecords.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuRecordsMouseClicked(evt);
            }
        });
        jPanel27.add(menuRecords, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 60, 50));

        jLabel33.setFont(new java.awt.Font("Dialog", 0, 9)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(0, 0, 0));
        jLabel33.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel33.setText("Records");
        jPanel27.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(3, 50, 50, -1));

        getContentPane().add(jPanel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 300, 60, 70));

        jPanel29.setBackground(new java.awt.Color(255, 255, 255));
        jPanel29.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel29.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel32.setFont(new java.awt.Font("Dialog", 0, 10)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(0, 0, 0));
        jLabel32.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel32.setText("Account");
        jPanel29.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(3, 50, 60, -1));

        menuAccount.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        menuAccount.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pos/images/user_1.png"))); // NOI18N
        menuAccount.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuAccountMouseClicked(evt);
            }
        });
        jPanel29.add(menuAccount, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 60, 50));

        getContentPane().add(jPanel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 540, 60, 70));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void searchuserKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchuserKeyPressed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_searchuserKeyPressed

    private void searchuserKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchuserKeyTyped
        // TODO add your handling code here:
        try
        {
            conn = dbconfig.db();
            String text = searchuser.getText();
            String sql = "Select Username,Password,Fullname,Role from tblaccount WHERE Fullname LIKE '%"+text+"%' AND Role<>'Superuser'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            tbluser.setModel(DbUtils.resultSetToTableModel(rs));
        }
        catch(Exception e)
        {
            e.getMessage();
        }
    }//GEN-LAST:event_searchuserKeyTyped

    private void btnRegisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegisterActionPerformed
        // TODO add your handling code here:
        String user = new_username.getText();
        String pass = new_password.getText();
        String name = new_name.getText();
        String role = (String) new_role.getSelectedItem();
        try
        {
            if(user.isEmpty()||pass.isEmpty()||name.isEmpty()||role.isEmpty())
            {
                JOptionPane.showMessageDialog(null,"Please fill in the form","Message",JOptionPane.WARNING_MESSAGE);
            }
            else
            {
                conn = dbconfig.db();
                String sql = "insert into tblaccount(Username,Password,Fullname,Role,Status)values(?,?,?,?,?)";
                pst = conn.prepareStatement(sql);
                pst.setString(1, user);
                pst.setString(2, pass);
                pst.setString(3, name);
                pst.setString(4, role);
                pst.setInt(5,1);
                pst.executeUpdate();
                JOptionPane.showMessageDialog(null,"Successfully added","Success",JOptionPane.INFORMATION_MESSAGE);
                loaduser();
            }
        }
        catch(HeadlessException | SQLException e)
        {
            JOptionPane.showMessageDialog(null,e.getMessage(),"ERROR",JOptionPane.ERROR_MESSAGE);
        }
        //empty the fields
        new_username.setText("");new_password.setText("");new_name.setText("");
        new_role.setSelectedIndex(0);
    }//GEN-LAST:event_btnRegisterActionPerformed

    private void search_supplierKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_search_supplierKeyTyped
        // TODO add your handling code here:
        try
        {
            String text = search_supplier.getText();
            conn = dbconfig.db();
            String sql = "Select BrandName as Brand,supplierName as Supplier,Address,contactNumber as Contact,emailAdd as Email,"
                    + "IF(Status=0,'Inactive','Active')Status from tblsupplier WHERE BrandName LIKE '%"+text+"%'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            tblsupplier.setModel(DbUtils.resultSetToTableModel(rs));
        }
        catch(Exception e)
        {
            e.getMessage();
        }
    }//GEN-LAST:event_search_supplierKeyTyped

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        newSupplier n = new newSupplier(new javax.swing.JFrame(), true);
        n.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProductActionPerformed
        // TODO add your handling code here:
        newProduct n = new newProduct(new javax.swing.JFrame(), true);
        n.setVisible(true);
    }//GEN-LAST:event_btnProductActionPerformed

    private void btnCategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCategoryActionPerformed
        // TODO add your handling code here:
        newCategory n = new newCategory(new javax.swing.JFrame(), true);
        n.setVisible(true);
    }//GEN-LAST:event_btnCategoryActionPerformed

    private void searchproductKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchproductKeyTyped
        // TODO add your handling code here:
        String text = searchproduct.getText();
        try
        {
            conn = dbconfig.db();
            String sql = "Select a.productCode as Code,a.itemDescription as Description,b.BrandName as Brand,b.supplierName as Supplier,c.CategoryName as Category"
                    + " from tblproduct a LEFT JOIN tblsupplier b ON b.supID=a.supID LEFT JOIN tblcategory c ON c.catID=a.catID WHERE "
                    + "a.itemDescription LIKE '%"+text+"%' OR a.productCode LIKE '%"+text+"%' GROUP BY a.productCode";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            tblproduct.setModel(DbUtils.resultSetToTableModel(rs));      
        }
        catch(Exception e)
        {
            e.getMessage();
        }
    }//GEN-LAST:event_searchproductKeyTyped

    private void btnStocksActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStocksActionPerformed
        // TODO add your handling code here:
        newStocks stocks = new newStocks(new javax.swing.JFrame(),true);
        stocks.show();
    }//GEN-LAST:event_btnStocksActionPerformed

    private void searchitemKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchitemKeyTyped
        // TODO add your handling code here:
        String text = searchitem.getText();
        try
        {
            conn = dbconfig.db();
            String sql = "Select a.productCode as Code,a.itemDescription as Description,c.BrandName as Brand,"
                + "FORMAT(IFNULL(b.costPrice,0),2)Cost,b.Unit,"
                + "FORMAT(IFNULL(SUM(b.Qty),0),0)Qty,b.itemCode as ItemCode,"
                + "IF(b.Qty<=0,'Out of Stocks',IF(b.Qty<=b.critical_level,'Critical Stocks','In Stocks'))Status from tblproduct a INNER JOIN tblinventory b ON a.productID=b.productID"
                + " LEFT JOIN tblsupplier c ON c.supID=a.supID WHERE "
                    + "a.itemDescription LIKE '%"+text+"%' OR a.productCode LIKE '%"+text+"%' OR c.BrandName LIKE '%"+text+"%' GROUP BY b.Unit,a.productID";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            jTable1.setModel(DbUtils.resultSetToTableModel(rs));
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null,e.getMessage(),"ERROR",JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_searchitemKeyTyped

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        int ask= JOptionPane.showConfirmDialog(this, "Add Stocks?","Question",JOptionPane.YES_OPTION,JOptionPane.QUESTION_MESSAGE);
        if(ask==JOptionPane.YES_OPTION)
        {
            int row = jTable1.getSelectedRow();
            String click=(jTable1.getModel().getValueAt(row, 6).toString()); 
            try
            {
                String get = "Select a.Qty,a.inID from tblinventory a INNER JOIN tblproduct b ON b.productID=a.productID WHERE "
                        + "a.itemCode=?";
                pst = conn.prepareStatement(get);
                pst.setString(1, click);
                rs = pst.executeQuery();
                if(rs.next())
                {
                    String value = JOptionPane.showInputDialog("Enter Quantity");
                    int new_qty = Integer.parseInt(value);
                    if(new_qty<0)
                    {
                        JOptionPane.showMessageDialog(null,"Invalid input value. Please try again","Message",JOptionPane.WARNING_MESSAGE);
                    }
                    else
                    {
                        int qty = rs.getInt("Qty");
                        int total = qty + new_qty;
                        //update the product
                        String query = "update tblinventory SET Qty=? WHERE inID=?";
                        pst = conn.prepareStatement(query);
                        pst.setInt(1, total);
                        pst.setString(2, rs.getString("inID"));
                        pst.executeUpdate();
                        JOptionPane.showMessageDialog(null,"Great! Successfully added","Success",JOptionPane.INFORMATION_MESSAGE);
                        loaditem();stocks();others();
                    }
                }
                else
                {
                    JOptionPane.showMessageDialog(null,"Invalid! Unable to update stocks with empty records","ERROR",JOptionPane.ERROR_MESSAGE);
                }
            }
            catch(HeadlessException | NumberFormatException | SQLException e)
            {
                JOptionPane.showMessageDialog(null,"Invalid input value","System Message",JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_jTable1MouseClicked

    private void searchitemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchitemActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchitemActionPerformed

    private void menuDashboardMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuDashboardMouseClicked
        // TODO add your handling code here:
        panel_1.setVisible(true);
        panel_2.setVisible(false);
        panel_3.setVisible(false);
        panel_4.setVisible(false);
        panel_5.setVisible(false);
    }//GEN-LAST:event_menuDashboardMouseClicked

    private void menuInventoryMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuInventoryMouseClicked
        // TODO add your handling code here:
        panel_1.setVisible(false);
        panel_2.setVisible(true);
        panel_3.setVisible(false);
        panel_4.setVisible(false);
        panel_5.setVisible(false);
    }//GEN-LAST:event_menuInventoryMouseClicked

    private void menuReportMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuReportMouseClicked
        // TODO add your handling code here:
        panel_1.setVisible(false);
        panel_2.setVisible(false);
        panel_4.setVisible(true);
        panel_3.setVisible(false);
        panel_5.setVisible(false);
    }//GEN-LAST:event_menuReportMouseClicked

    private void menuMaintenanceMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuMaintenanceMouseClicked
        // TODO add your handling code here:
        panel_1.setVisible(false);
        panel_2.setVisible(false);
        panel_4.setVisible(false);
        panel_3.setVisible(true);
        panel_5.setVisible(false);
    }//GEN-LAST:event_menuMaintenanceMouseClicked

    private void btnLogoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnLogoutMouseClicked
        // TODO add your handling code here:
        int quit = JOptionPane.showConfirmDialog(null,"Signing out?","Message",JOptionPane.YES_OPTION,JOptionPane.QUESTION_MESSAGE);
        if(quit==JOptionPane.YES_OPTION)
        {
            home h = new home();
            h.setVisible(true);
            this.setVisible(false);
            try
            {
                conn.close();
                pst.close();
                rs.close();
            }
            catch(SQLException e)
            {
                e.getMessage();
            }
        }
    }//GEN-LAST:event_btnLogoutMouseClicked

    private void menuAccountMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuAccountMouseClicked
        // TODO add your handling code here:
        newPassword pass = new newPassword(new javax.swing.JFrame(),true);
        pass.show();
    }//GEN-LAST:event_menuAccountMouseClicked

    private void tbluserMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbluserMouseClicked
        // TODO add your handling code here:
        int ask= JOptionPane.showConfirmDialog(this, "Change Password?","Question",JOptionPane.YES_OPTION,JOptionPane.QUESTION_MESSAGE);
        if(ask==JOptionPane.YES_OPTION)
        {
            int row = tbluser.getSelectedRow();
            String click=(tbluser.getModel().getValueAt(row, 2).toString()); 
            changePassword cp = new changePassword(new javax.swing.JFrame(),true);
            changePassword.fullname.setText(click);
            cp.show();
        }
    }//GEN-LAST:event_tbluserMouseClicked

    private void btnLoadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLoadActionPerformed
        // TODO add your handling code here:
        try
        {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String fdate = sdf.format(fromdate.getDate());
            String tdate = sdf.format(todate.getDate());
            conn = dbconfig.db();
            String sql = "Select b.itemDescription as ItemDescription,a.itemCode as ItemCode,"
                    + "FORMAT(a.Qty,0)OnHand,"
                    + "IFNULL(c.SoldItem,0)SoldItem,"
                    + "IFNULL(d.Used,0)UsedItem,"
                    + "IFNULL(d.Damaged,0) DamagedItem,"
                    + "IFNULL(d.Lost,0)MissingItem,"
                    + "FORMAT((a.Qty+IFNULL(c.SoldItem,0)+IFNULL(d.Used,0)+IFNULL(d.Damaged,0)+IFNULL(d.Lost,0)),0)Total from tblinventory a LEFT JOIN tblproduct b on b.productID=a.productID "
                    + "LEFT JOIN "
                    + "(Select itemCode, FORMAT(SUM(Qty),0)SoldItem from tblitems WHERE TransactionDate BETWEEN '"+fdate+"' AND '"+tdate+"' GROUP BY itemCode)c ON c.itemCode=a.itemCode "
                    + "LEFT JOIN (Select itemCode, "
                    + "SUM(CASE WHEN TypeofReport='Used Item' THEN Qty ELSE 0 END)Used, "
                    + "SUM(CASE WHEN TypeofReport='Damaged Item' THEN Qty ELSE 0 END)Damaged, "
                    + "SUM(CASE WHEN TypeofReport='Missing Item' THEN Qty ELSE 0 END)Lost from tblothers WHERE Date BETWEEN '"+fdate+"' AND '"+tdate+"' GROUP BY itemCode)d ON d.itemCode=a.itemCode "
                    + "GROUP BY a.itemCode";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            jTable2.setModel(DbUtils.resultSetToTableModel(rs));
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }//GEN-LAST:event_btnLoadActionPerformed

    private void btnExportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExportActionPerformed
        // TODO add your handling code here:
        try
        {
            conn = dbconfig.db();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String fdate = sdf.format(fromdate.getDate());
            String tdate = sdf.format(todate.getDate());
            JasperDesign jd = JRXmlLoader.load(getClass().getResourceAsStream("/reports/sales.jrxml"));
            String sql = "Select b.itemDescription as ItemDescription,a.itemCode as ItemCode,"
                    + "FORMAT(a.Qty,0)OnHold,"
                    + "IFNULL(c.SoldItem,0)SoldItem,"
                    + "IFNULL(d.Used,0)UsedItem,"
                    + "IFNULL(d.Damaged,0) DamagedItem,"
                    + "IFNULL(d.Lost,0)LostItem,"
                    + "FORMAT((a.Qty+IFNULL(c.SoldItem,0)+IFNULL(d.Used,0)+IFNULL(d.Damaged,0)+IFNULL(d.Lost,0)),0)Total from tblinventory a LEFT JOIN tblproduct b on b.productID=a.productID "
                    + "LEFT JOIN "
                    + "(Select itemCode, FORMAT(SUM(Qty),0)SoldItem from tblitems WHERE TransactionDate BETWEEN '"+fdate+"' AND '"+tdate+"' GROUP BY itemCode)c ON c.itemCode=a.itemCode "
                    + "LEFT JOIN (Select itemCode, "
                    + "SUM(CASE WHEN TypeofReport='Used Item' THEN Qty ELSE 0 END)Used, "
                    + "SUM(CASE WHEN TypeofReport='Damaged Item' THEN Qty ELSE 0 END)Damaged, "
                    + "SUM(CASE WHEN TypeofReport='Lost Item' THEN Qty ELSE 0 END)Lost from tblothers WHERE Date BETWEEN '"+fdate+"' AND '"+tdate+"' GROUP BY itemCode)d ON d.itemCode=a.itemCode "
                    + "GROUP BY a.itemCode";
            JRDesignQuery newQ = new JRDesignQuery();
            newQ.setText(sql);
            jd.setQuery(newQ);
            JasperReport jr = JasperCompileManager.compileReport(jd);
            JasperPrint jp = JasperFillManager.fillReport(jr, null, conn);
            JasperViewer.viewReport(jp,false);
        }
        catch(JRException e)
        {
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }//GEN-LAST:event_btnExportActionPerformed

    private void btnGenerateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGenerateActionPerformed
        // TODO add your handling code here:       
        try
        {
            conn = dbconfig.db();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String fdate = sdf.format(from_sales_date.getDate());
            String tdate = sdf.format(to_sales_date.getDate());
            String sql = "Select a.TransactionDate,a.TransactionCode,FORMAT(totalAmount,2)Gross_Profit,FORMAT(vatAmount,2)Vat,FORMAT(WithTax,2)Net_Profit,a.username as Username from tblsales a "
                    + "WHERE a.TransactionDate BETWEEN '"+fdate+"' AND '"+tdate+"' GROUP BY a.TransactionCode";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            tblsales.setModel(DbUtils.resultSetToTableModel(rs));
            //get the total
            String query = "Select FORMAT(IFNULL(SUM(WithTax),0),2)total from tblsales WHERE TransactionDate BETWEEN '"+fdate+"' AND '"+tdate+"'";
            pst = conn.prepareStatement(query);
            rs = pst.executeQuery();
            if(rs.next())
            {
                total_Sales.setText(rs.getString("total"));
            }
            //get the total
            String querys = "Select FORMAT(IFNULL(SUM(vatAmount),0),2)total from tblsales WHERE TransactionDate BETWEEN '"+fdate+"' AND '"+tdate+"'";
            pst = conn.prepareStatement(querys);
            rs = pst.executeQuery();
            if(rs.next())
            {
                total_vat.setText(rs.getString("total"));
            }
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }//GEN-LAST:event_btnGenerateActionPerformed

    private void tblsalesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblsalesMouseClicked
        // open list
        int ask= JOptionPane.showConfirmDialog(this, "View Items?","Question",JOptionPane.YES_OPTION,JOptionPane.QUESTION_MESSAGE);
        if(ask==JOptionPane.YES_OPTION)
        {
            try
            {
                conn = dbconfig.db();
                JasperDesign jd = JRXmlLoader.load(getClass().getResourceAsStream("/reports/list_item.jrxml"));
                int row = tblsales.getSelectedRow();
                String click=(tblsales.getModel().getValueAt(row, 1).toString());
                String sql = "Select TransactionCode,itemDescription as Description,itemCode as ItemCode, Qty,Unit,FORMAT(Amount,2)Amount from tblitems "
                        + "WHERE TransactionCode='"+click+"'"
                        + " GROUP BY itemID";
                JRDesignQuery newQ = new JRDesignQuery();
                newQ.setText(sql);
                jd.setQuery(newQ);
                JasperReport jr = JasperCompileManager.compileReport(jd);
                JasperPrint jp = JasperFillManager.fillReport(jr, null, conn);
                JasperViewer.viewReport(jp,false);
            }
            catch(JRException e)
            {
                JOptionPane.showMessageDialog(null,e.getMessage());
            }            
        }
    }//GEN-LAST:event_tblsalesMouseClicked

    private void btnexport_salesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnexport_salesActionPerformed
        // TODO add your handling code here:
        try
        {
            conn = dbconfig.db();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String fdate = sdf.format(from_sales_date.getDate());
            String tdate = sdf.format(to_sales_date.getDate());
            JasperDesign jd = JRXmlLoader.load(getClass().getResourceAsStream("/reports/sales_report.jrxml"));
            String sql = "Select a.TransactionDate,a.TransactionCode,FORMAT(totalAmount,2)Gross_Profit,FORMAT(vatAmount,2)Vat,FORMAT(WithTax,2)Net_Profit,a.username as Username from tblsales a "
                    + "WHERE a.TransactionDate BETWEEN '"+fdate+"' AND '"+tdate+"' GROUP BY a.TransactionCode";
            JRDesignQuery newQ = new JRDesignQuery();
            newQ.setText(sql);
            jd.setQuery(newQ);
            JasperReport jr = JasperCompileManager.compileReport(jd);
            JasperPrint jp = JasperFillManager.fillReport(jr, null, conn);
            JasperViewer.viewReport(jp,false);
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }//GEN-LAST:event_btnexport_salesActionPerformed

    private void menuRecordsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuRecordsMouseClicked
        // TODO add your handling code here:
        panel_5.setVisible(true);
        panel_2.setVisible(false);
        panel_3.setVisible(false);
        panel_4.setVisible(false);
        panel_1.setVisible(false);
    }//GEN-LAST:event_menuRecordsMouseClicked

    private void searchbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchbtnActionPerformed
        // TODO add your handling code here:
        try
        {
            conn = dbconfig.db();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String fdate = sdf.format(fromProductDate.getDate());
            String tdate = sdf.format(toProductDate.getDate());
            String sql = "Select a.TransactionDate as Date,a.itemCode as ItemCode,a.itemDescription as Description,FORMAT(SUM(a.Qty),0)Qty,FORMAT(SUM(a.Amount),2)Amount from tblitems a "
                    + "WHERE a.TransactionCode!='' AND a.TransactionDate BETWEEN '"+fdate+"' AND '"+tdate+"' GROUP BY a.TransactionDate,a.itemCode ORDER BY Qty DESC";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            jTable3.setModel(DbUtils.resultSetToTableModel(rs));
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }//GEN-LAST:event_searchbtnActionPerformed

    private void menuPOSMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuPOSMouseClicked
        // TODO add your handling code here:
        POS pos = new POS(new javax.swing.JFrame(),true);
        pos.show();
    }//GEN-LAST:event_menuPOSMouseClicked

    private void label_instocksMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_label_instocksMouseClicked
        // TODO add your handling code here:
        try
        {
            conn = dbconfig.db();
            JasperDesign jd = JRXmlLoader.load(getClass().getResourceAsStream("/reports/instocks.jrxml"));
            String sql = "Select a.itemDescription as Description,\n" +
            "b.itemCode as ItemCode from tblproduct a INNER JOIN tblinventory b ON a.productID=b.productID WHERE b.Qty>10 GROUP BY b.Unit,a.productID";
            JRDesignQuery newQ = new JRDesignQuery();
            newQ.setText(sql);
            jd.setQuery(newQ);
            JasperReport jr = JasperCompileManager.compileReport(jd);
            JasperPrint jp = JasperFillManager.fillReport(jr, null, conn);
            JasperViewer.viewReport(jp,false);
        }
        catch(JRException e)
        {
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }//GEN-LAST:event_label_instocksMouseClicked

    private void label_outstocksMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_label_outstocksMouseClicked
        // TODO add your handling code here:
        try
        {
            conn = dbconfig.db();
            JasperDesign jd = JRXmlLoader.load(getClass().getResourceAsStream("/reports/outstocks.jrxml"));
            String sql = "Select a.itemDescription as Description,\n" +
            "b.itemCode as ItemCode from tblproduct a INNER JOIN tblinventory b ON a.productID=b.productID WHERE b.Qty<=0 GROUP BY b.Unit,a.productID";
            JRDesignQuery newQ = new JRDesignQuery();
            newQ.setText(sql);
            jd.setQuery(newQ);
            JasperReport jr = JasperCompileManager.compileReport(jd);
            JasperPrint jp = JasperFillManager.fillReport(jr, null, conn);
            JasperViewer.viewReport(jp,false);
        }
        catch(JRException e)
        {
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }//GEN-LAST:event_label_outstocksMouseClicked

    private void label_criticalstockMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_label_criticalstockMouseClicked
        // TODO add your handling code here:       
        try
        {
            conn = dbconfig.db();
            JasperDesign jd = JRXmlLoader.load(getClass().getResourceAsStream("/reports/criticalstocks.jrxml"));
            String sql = "Select a.itemDescription as Description,\n" +
            "b.itemCode as ItemCode from tblproduct a INNER JOIN tblinventory b ON a.productID=b.productID WHERE b.Qty BETWEEN 1 AND 10 GROUP BY b.Unit,a.productID";
            JRDesignQuery newQ = new JRDesignQuery();
            newQ.setText(sql);
            jd.setQuery(newQ);
            JasperReport jr = JasperCompileManager.compileReport(jd);
            JasperPrint jp = JasperFillManager.fillReport(jr, null, conn);
            JasperViewer.viewReport(jp,false);
        }
        catch(JRException e)
        {
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }//GEN-LAST:event_label_criticalstockMouseClicked

    private void exportbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exportbtnActionPerformed
        // TODO add your handling code here:
        try
        {
            conn = dbconfig.db();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String fdate = sdf.format(fromProductDate.getDate());
            String tdate = sdf.format(toProductDate.getDate());
            JasperDesign jd = JRXmlLoader.load(getClass().getResourceAsStream("/reports/product.jrxml"));
            String sql = "Select a.TransactionDate as Date,a.itemCode as ItemCode,a.itemDescription as Description,FORMAT(SUM(a.Qty),0)Qty,FORMAT(SUM(a.Amount),2)Amount from tblitems a "
                    + "WHERE a.TransactionCode!='' AND a.TransactionDate BETWEEN '"+fdate+"' AND '"+tdate+"' GROUP BY a.TransactionDate,a.itemCode ORDER BY Qty DESC";
            JRDesignQuery newQ = new JRDesignQuery();
            newQ.setText(sql);
            jd.setQuery(newQ);
            JasperReport jr = JasperCompileManager.compileReport(jd);
            JasperPrint jp = JasperFillManager.fillReport(jr, null, conn);
            JasperViewer.viewReport(jp,false);
        }
        catch(JRException e)
        {
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }//GEN-LAST:event_exportbtnActionPerformed

    private void search_others_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_search_others_btnActionPerformed
        // TODO add your handling code here:
        try
        {
            conn = dbconfig.db();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String fdate = sdf.format(others_fdate.getDate());
            String tdate = sdf.format(others_tdate.getDate());
            String cat = (String)select_category.getSelectedItem();
            //query
            String sql = "Select a.Date,a.itemCode as ItemCode,c.itemDescription as Description," 
                    + "FORMAT(IFNULL(a.Qty,0),0)Qty,a.Details as Remarks from tblothers a " 
                    + "INNER JOIN tblinventory b ON b.itemCode=a.itemCode LEFT JOIN tblproduct c ON c.productID=b.productID "
                    + "WHERE a.Date BETWEEN '"+fdate+"' AND '"+tdate+"' AND a.TypeofReport='"+cat+"' GROUP BY a.oID";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            tbl_others.setModel(DbUtils.resultSetToTableModel(rs));
           
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }//GEN-LAST:event_search_others_btnActionPerformed

    private void export_others_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_export_others_btnActionPerformed
        // TODO add your handling code here:
        try
        {
            conn = dbconfig.db();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String fdate = sdf.format(others_fdate.getDate());
            String tdate = sdf.format(others_tdate.getDate());
            String cat = (String)select_category.getSelectedItem();
            JasperDesign jd = JRXmlLoader.load(getClass().getResourceAsStream("/reports/others.jrxml"));
            String sql = "Select a.Date,a.itemCode as ItemCode,c.itemDescription as Description," 
                    + "FORMAT(IFNULL(a.Qty,0),0)Qty,a.Details as Remarks from tblothers a " 
                    + "INNER JOIN tblinventory b ON b.itemCode=a.itemCode LEFT JOIN tblproduct c ON c.productID=b.productID "
                    + "WHERE a.Date BETWEEN '"+fdate+"' AND '"+tdate+"' AND a.TypeofReport='"+cat+"' GROUP BY a.oID";
            JRDesignQuery newQ = new JRDesignQuery();
            newQ.setText(sql);
            jd.setQuery(newQ);
            JasperReport jr = JasperCompileManager.compileReport(jd);
            JasperPrint jp = JasperFillManager.fillReport(jr, null, conn);
            JasperViewer.viewReport(jp,false);
        }
        catch(JRException e)
        {
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }//GEN-LAST:event_export_others_btnActionPerformed

    private void search_categoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_search_categoryActionPerformed
        // TODO add your handling code here:
        try
        {
            conn = dbconfig.db();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String fdate = sdf.format(category_fdate.getDate());
            String tdate = sdf.format(category_tdate.getDate());
            String sql = "SELECT a.CategoryName,FORMAT(c.Amount,2)Amount from tblcategory a LEFT JOIN tblproduct b on b.catID=a.catID "
                    + "LEFT JOIN (Select productID,SUM(Amount)Amount from tblitems WHERE TransactionDate BETWEEN '"+fdate+"' AND '"+tdate+"' GROUP BY productID) c ON c.productID=b.productID group by a.CategoryName";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            jTable4.setModel(DbUtils.resultSetToTableModel(rs));
            //total
            String query = "Select FORMAT(SUM(t2.Amount),2)Amount from tblitems t2  "
            + "WHERE t2.TransactionDate BETWEEN '"+fdate+"' AND '"+tdate+"'";
            pst = conn.prepareStatement(query);
            rs = pst.executeQuery();
            if(rs.next())
            {
                total_category.setText(rs.getString("Amount"));
            }
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }//GEN-LAST:event_search_categoryActionPerformed

    private void export_categoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_export_categoryActionPerformed
        // TODO add your handling code here:
        try
        {
            conn = dbconfig.db();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String fdate = sdf.format(category_fdate.getDate());
            String tdate = sdf.format(category_tdate.getDate());
            JasperDesign jd = JRXmlLoader.load(getClass().getResourceAsStream("/reports/category_sales.jrxml"));
            String sql = "SELECT a.CategoryName,FORMAT(c.Amount,2)Amount from tblcategory a LEFT JOIN tblproduct b on b.catID=a.catID "
                    + "LEFT JOIN (Select productID,SUM(Amount)Amount from tblitems WHERE TransactionDate BETWEEN '"+fdate+"' AND '"+tdate+"' GROUP BY productID) c ON c.productID=b.productID group by a.CategoryName";
            JRDesignQuery newQ = new JRDesignQuery();
            newQ.setText(sql);
            jd.setQuery(newQ);
            HashMap<String, Object> para = new HashMap<>();
            para.put("total",total_category.getText());
            JasperReport jr = JasperCompileManager.compileReport(jd);
            JasperPrint jp = JasperFillManager.fillReport(jr, para, conn);
            JasperViewer.viewReport(jp,false);
        }
        catch(JRException e)
        {
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }//GEN-LAST:event_export_categoryActionPerformed

    private void searchlogsKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchlogsKeyPressed
        // TODO add your handling code here:
        try
        {
            String text = searchlogs.getText();
            String sql = "Select Fullname,DateTime,Remarks from tbl_logs WHERE Fullname LIKE '%"+text+"%' OR DateTime LIKE '%"+text+"%' OR Remarks LIKE '%"+text+"%'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            jTable5.setModel(DbUtils.resultSetToTableModel(rs));
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null,e.fillInStackTrace(),"ERROR",JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_searchlogsKeyPressed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        others();
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new dashboard().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCategory;
    private javax.swing.JButton btnExport;
    private javax.swing.JButton btnGenerate;
    private javax.swing.JButton btnLoad;
    private javax.swing.JLabel btnLogout;
    private javax.swing.JButton btnProduct;
    private javax.swing.JButton btnRegister;
    private javax.swing.JButton btnStocks;
    private javax.swing.JButton btnexport_sales;
    private com.toedter.calendar.JDateChooser category_fdate;
    private com.toedter.calendar.JDateChooser category_tdate;
    public static javax.swing.JLabel current_month;
    public static javax.swing.JLabel currentstocks;
    public static javax.swing.JLabel daily_sales;
    public static javax.swing.JPanel daily_sales_chart;
    private javax.swing.JButton export_category;
    private javax.swing.JButton export_others_btn;
    private javax.swing.JButton exportbtn;
    private com.toedter.calendar.JDateChooser fromProductDate;
    private com.toedter.calendar.JDateChooser from_sales_date;
    private com.toedter.calendar.JDateChooser fromdate;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTabbedPane jTabbedPane3;
    public static javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTable jTable4;
    public static javax.swing.JTable jTable5;
    public static javax.swing.JLabel label_criticalstock;
    public static javax.swing.JLabel label_instocks;
    public static javax.swing.JLabel label_outstocks;
    public static javax.swing.JLabel label_yearly;
    private javax.swing.JLabel menuAccount;
    private javax.swing.JLabel menuDashboard;
    private javax.swing.JLabel menuInventory;
    private javax.swing.JLabel menuMaintenance;
    private javax.swing.JLabel menuPOS;
    private javax.swing.JLabel menuRecords;
    private javax.swing.JLabel menuReport;
    public static javax.swing.JPanel monthly_chart;
    private javax.swing.JTextField new_name;
    private javax.swing.JPasswordField new_password;
    private javax.swing.JComboBox<String> new_role;
    private javax.swing.JTextField new_username;
    private com.toedter.calendar.JDateChooser others_fdate;
    private com.toedter.calendar.JDateChooser others_tdate;
    private javax.swing.JPanel panel_1;
    private javax.swing.JPanel panel_2;
    private javax.swing.JPanel panel_3;
    private javax.swing.JPanel panel_4;
    private javax.swing.JPanel panel_5;
    public static javax.swing.JLabel previous_sales;
    private javax.swing.JButton search_category;
    private javax.swing.JButton search_others_btn;
    private javax.swing.JTextField search_supplier;
    private javax.swing.JButton searchbtn;
    private javax.swing.JTextField searchitem;
    private javax.swing.JTextField searchlogs;
    private javax.swing.JTextField searchproduct;
    private javax.swing.JTextField searchuser;
    private javax.swing.JComboBox<String> select_category;
    public static javax.swing.JLabel stocksvalue;
    private javax.swing.JTable tbl_others;
    public static javax.swing.JTable tblcategory;
    public static javax.swing.JTable tblproduct;
    public static javax.swing.JTable tblsales;
    public static javax.swing.JTable tblsupplier;
    public static javax.swing.JTable tbluser;
    private javax.swing.JLabel time;
    private com.toedter.calendar.JDateChooser toProductDate;
    private com.toedter.calendar.JDateChooser to_sales_date;
    private com.toedter.calendar.JDateChooser todate;
    private javax.swing.JLabel total_Sales;
    private javax.swing.JLabel total_Sales1;
    private javax.swing.JLabel total_Sales2;
    private javax.swing.JLabel total_Sales3;
    private javax.swing.JLabel total_category;
    public static javax.swing.JLabel total_trxn;
    private javax.swing.JLabel total_vat;
    public static javax.swing.JLabel txtDamaged;
    public static javax.swing.JLabel txtLost;
    public static javax.swing.JLabel txtOnhand;
    public static javax.swing.JLabel txtUsed;
    public static javax.swing.JLabel user_name;
    // End of variables declaration//GEN-END:variables
}
